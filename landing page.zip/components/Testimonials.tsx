import type { Testimonial } from "@/types";
import styles from "./Testimonials.module.css";

const testimonials: Testimonial[] = [
  {
    name: "Tunde A.",
    stars: 5,
    text: '"Altioda is the best platform I\'ve used. Fast transactions and great support!"',
    initials: "TA",
    color: "#1e88e5",
  },
  {
    name: "Chioma K.",
    stars: 4,
    text: '"As a beginner, this platform is so easy to use, I love it!"',
    initials: "CK",
    color: "#00c853",
  },
  {
    name: "Emeka B.",
    stars: 5,
    text: '"Secure, reliable and trustworthy. Highly recommended!"',
    initials: "EB",
    color: "#e53935",
  },
];

function Stars({ count }: { count: number }) {
  return (
    <div className={styles.stars}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span
          key={i}
          className={i < count ? styles.starFilled : styles.starEmpty}
        >
          ★
        </span>
      ))}
    </div>
  );
}

export default function Testimonials() {
  return (
    <section className={styles.section}>
      <div className={styles.container}>
        <h2 className={styles.heading} data-aos="fade-up">
          What Our <span className={styles.accent}>Users Say</span>
        </h2>

        <div className={styles.grid}>
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className={styles.card}
              data-aos="fade-up"
              data-aos-delay={i * 100}
            >
              <div className={styles.userRow}>
                <div className={styles.avatar} style={{ background: t.color }}>
                  {t.initials}
                </div>
                <div>
                  <div className={styles.name}>{t.name}</div>
                  <Stars count={t.stars} />
                </div>
              </div>
              <p className={styles.quote}>{t.text}</p>
            </div>
          ))}
        </div>

        <div className={styles.dots}>
          <span className={`${styles.dot} ${styles.active}`} />
          <span className={styles.dot} />
          <span className={styles.dot} />
        </div>
      </div>
    </section>
  );
}
