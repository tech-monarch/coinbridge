import { Link } from "react-router-dom";
import styles from "./UrgencyBanner.module.css";

export default function UrgencyBanner() {
  return (
    <section className={styles.section}>
      <div className={styles.container}>
        <div className={styles.rocket} data-aos="fade-right">
          <div className={styles.rocketPlaceholder}>
            <svg
              width="120"
              height="120"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#1e88e5"
              strokeWidth="1.5"
              className={styles.rocketImg}
            >
              <path d="M4 14.899A7 7 0 1 1 15.71 8m-4.857-3.5L17 3m-4 0l-2.5 1.5m1 16s4.5-1 4.5-5.5c0-1.5-.906-3-2.25-3.75m-4.5 9.25s-4.5-1-4.5-5.5c0-1.5.906-3 2.25-3.75m4.5 0h.5m-6 0h.5" />
            </svg>
          </div>
        </div>
        <div className={styles.content} data-aos="fade-up" data-aos-delay="100">
          <h2 className={styles.heading}>
            The Future of Money is Digital — Don't Get Left Behind
          </h2>
          <p className={styles.sub}>
            More people are joining the crypto revolution every day.
            <br />
            Start today and take control of your financial future.
          </p>
        </div>
        <Link
          to="/register"
          className={styles.btn}
          data-aos="fade-left"
          data-aos-delay="150"
        >
          Create Free Account &nbsp;→
        </Link>
      </div>
    </section>
  );
}
