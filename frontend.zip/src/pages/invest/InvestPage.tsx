import { useState } from "react";
import styles from "./InvestPage.module.css";
import { useAuth } from "@/context/AuthContext";
import { formatUSD } from "@/services/prices";

// ─── Demo Data ───────────────────────────────────────────────────────────────

const COINS = [
  {
    symbol: "BTC",
    name: "Bitcoin",
    price: 67842.5,
    change: +2.34,
    color: "#f7931a",
    icon: "₿",
    volume: "$38.2B",
    high: "$68,910",
    low: "$65,420",
  },
  {
    symbol: "ETH",
    name: "Ethereum",
    price: 3521.8,
    change: +1.87,
    color: "#627eea",
    icon: "Ξ",
    volume: "$18.4B",
    high: "$3,590",
    low: "$3,390",
  },
  {
    symbol: "BNB",
    name: "BNB",
    price: 612.4,
    change: -0.63,
    color: "#f0b90b",
    icon: "⬥",
    volume: "$2.1B",
    high: "$621",
    low: "$601",
  },
  {
    symbol: "SOL",
    name: "Solana",
    price: 162.75,
    change: +4.12,
    color: "#9945ff",
    icon: "◎",
    volume: "$4.8B",
    high: "$167",
    low: "$154",
  },
  {
    symbol: "XRP",
    name: "XRP",
    price: 2.18,
    change: +0.92,
    color: "#00aae4",
    icon: "✕",
    volume: "$3.2B",
    high: "$2.24",
    low: "$2.10",
  },
  {
    symbol: "ADA",
    name: "Cardano",
    price: 0.452,
    change: -1.44,
    color: "#0033ad",
    icon: "₳",
    volume: "$0.8B",
    high: "$0.468",
    low: "$0.438",
  },
  {
    symbol: "AVAX",
    name: "Avalanche",
    price: 38.92,
    change: +3.21,
    color: "#e84142",
    icon: "A",
    volume: "$0.9B",
    high: "$40.10",
    low: "$37.20",
  },
  {
    symbol: "DOGE",
    name: "Dogecoin",
    price: 0.162,
    change: -2.11,
    color: "#c2a633",
    icon: "Ð",
    volume: "$1.2B",
    high: "$0.171",
    low: "$0.158",
  },
];

const ORDER_BOOK_ASKS = [
  { price: 67920.0, amount: 0.2841, total: 19294 },
  { price: 67905.5, amount: 0.5012, total: 34045 },
  { price: 67890.0, amount: 1.1234, total: 76303 },
  { price: 67875.0, amount: 0.33, total: 22399 },
  { price: 67860.0, amount: 0.88, total: 59717 },
];

const ORDER_BOOK_BIDS = [
  { price: 67842.5, amount: 0.4512, total: 30621 },
  { price: 67830.0, amount: 0.99, total: 67152 },
  { price: 67815.0, amount: 0.221, total: 15007 },
  { price: 67800.0, amount: 1.55, total: 105090 },
  { price: 67785.0, amount: 0.66, total: 44738 },
];

const RECENT_TRADES = [
  { time: "14:32:05", price: 67842.5, amount: 0.1234, side: "buy" },
  { time: "14:32:01", price: 67838.0, amount: 0.0512, side: "sell" },
  { time: "14:31:58", price: 67840.0, amount: 0.331, side: "buy" },
  { time: "14:31:54", price: 67835.5, amount: 0.22, side: "sell" },
  { time: "14:31:50", price: 67842.0, amount: 0.0888, side: "buy" },
  { time: "14:31:46", price: 67830.0, amount: 0.44, side: "sell" },
  { time: "14:31:43", price: 67845.0, amount: 0.11, side: "buy" },
  { time: "14:31:39", price: 67828.0, amount: 0.066, side: "sell" },
];

const OPEN_ORDERS = [
  {
    date: "2025-06-01",
    pair: "BTC/USD",
    type: "Limit",
    side: "Buy",
    price: "$66,000",
    amount: "0.05 BTC",
    filled: "0%",
    status: "Open",
  },
  {
    date: "2025-05-30",
    pair: "ETH/USD",
    type: "Market",
    side: "Sell",
    price: "Market",
    amount: "0.50 ETH",
    filled: "100%",
    status: "Filled",
  },
  {
    date: "2025-05-29",
    pair: "SOL/USD",
    type: "Limit",
    side: "Buy",
    price: "$150",
    amount: "10 SOL",
    filled: "50%",
    status: "Partial",
  },
];

// ─── Chart (simple SVG candlesticks) ─────────────────────────────────────────

const CANDLES = [
  { o: 65420, h: 66800, l: 65100, c: 66500 },
  { o: 66500, h: 67200, l: 66100, c: 66900 },
  { o: 66900, h: 67500, l: 66600, c: 67200 },
  { o: 67200, h: 67800, l: 66900, c: 67100 },
  { o: 67100, h: 67600, l: 66800, c: 67450 },
  { o: 67450, h: 68100, l: 67200, c: 67900 },
  { o: 67900, h: 68400, l: 67500, c: 68100 },
  { o: 68100, h: 68600, l: 67700, c: 67843 },
];

function CandleChart() {
  const W = 560,
    H = 200;
  const priceMin = Math.min(...CANDLES.map((c) => c.l)) - 200;
  const priceMax = Math.max(...CANDLES.map((c) => c.h)) + 200;
  const range = priceMax - priceMin;
  const colW = W / CANDLES.length;

  const py = (price: number) => H - ((price - priceMin) / range) * H;

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      height="100%"
      preserveAspectRatio="none"
    >
      <defs>
        <linearGradient id="chartBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1565C0" stopOpacity="0.08" />
          <stop offset="100%" stopColor="#1565C0" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* grid lines */}
      {[0.25, 0.5, 0.75].map((t) => (
        <line
          key={t}
          x1="0"
          y1={H * t}
          x2={W}
          y2={H * t}
          stroke="#e8ecf0"
          strokeWidth="1"
          strokeDasharray="4 4"
        />
      ))}
      {CANDLES.map((c, i) => {
        const x = i * colW + colW / 2;
        const bull = c.c >= c.o;
        const color = bull ? "#22c55e" : "#ef4444";
        const bodyTop = py(Math.max(c.o, c.c));
        const bodyBot = py(Math.min(c.o, c.c));
        const bodyH = Math.max(bodyBot - bodyTop, 2);
        return (
          <g key={i}>
            <line
              x1={x}
              y1={py(c.h)}
              x2={x}
              y2={py(c.l)}
              stroke={color}
              strokeWidth="1.5"
            />
            <rect
              x={x - colW * 0.3}
              y={bodyTop}
              width={colW * 0.6}
              height={bodyH}
              fill={color}
              rx="1"
            />
          </g>
        );
      })}
    </svg>
  );
}

// ─── Volume bars ──────────────────────────────────────────────────────────────

const VOLUMES = [18, 24, 31, 22, 27, 35, 42, 29];

function VolumeChart() {
  const max = Math.max(...VOLUMES);
  const W = 560,
    H = 48;
  const colW = W / VOLUMES.length;
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      height="100%"
      preserveAspectRatio="none"
    >
      {VOLUMES.map((v, i) => {
        const barH = (v / max) * (H - 6);
        const bull = CANDLES[i].c >= CANDLES[i].o;
        return (
          <rect
            key={i}
            x={i * colW + colW * 0.15}
            y={H - barH}
            width={colW * 0.7}
            height={barH}
            fill={bull ? "#22c55e" : "#ef4444"}
            opacity="0.5"
            rx="2"
          />
        );
      })}
    </svg>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function InvestPage() {
  const { user } = useAuth();
  const balance = user ? Number(user.balance) : 0;

  const [selectedCoin, setSelectedCoin] = useState(COINS[0]);
  const [orderSide, setOrderSide] = useState<"buy" | "sell">("buy");
  const [orderType, setOrderType] = useState<"market" | "limit" | "stop">(
    "market",
  );
  const [amount, setAmount] = useState("");
  const [limitPrice, setLimitPrice] = useState("");
  const [chartInterval, setChartInterval] = useState("1H");
  const [activeTab, setActiveTab] = useState<"orderbook" | "trades">(
    "orderbook",
  );
  const [ordersTab, setOrdersTab] = useState<"open" | "history">("open");

  const estTotal = amount
    ? (parseFloat(amount) * selectedCoin.price).toFixed(2)
    : "0.00";
  const positive = selectedCoin.change >= 0;

  const handlePercentage = (pct: number) => {
    const maxBuy = balance / selectedCoin.price;
    const demoHolding = 0.5; // demo holding for sell
    const base = orderSide === "buy" ? maxBuy : demoHolding;
    setAmount(((base * pct) / 100).toFixed(6));
  };

  return (
    <div className={styles.page}>
      {/* ── Top ticker bar ── */}
      <div className={styles.tickerBar}>
        {COINS.map((c) => (
          <button
            key={c.symbol}
            className={`${styles.tickerItem} ${selectedCoin.symbol === c.symbol ? styles.tickerActive : ""}`}
            onClick={() => setSelectedCoin(c)}
          >
            <span
              className={styles.tickerIcon}
              style={{ color: c.color, background: `${c.color}18` }}
            >
              {c.icon}
            </span>
            <span className={styles.tickerSymbol}>{c.symbol}</span>
            <span
              className={`${styles.tickerChange} ${c.change >= 0 ? styles.pos : styles.neg}`}
            >
              {c.change >= 0 ? "▲" : "▼"} {Math.abs(c.change).toFixed(2)}%
            </span>
          </button>
        ))}
      </div>

      {/* ── Main grid ── */}
      <div className={styles.mainGrid}>
        {/* ── LEFT: Chart column ── */}
        <div className={styles.chartCol}>
          {/* Pair header */}
          <div className={styles.pairHeader}>
            <div className={styles.pairLeft}>
              <div
                className={styles.pairIcon}
                style={{
                  color: selectedCoin.color,
                  background: `${selectedCoin.color}20`,
                }}
              >
                {selectedCoin.icon}
              </div>
              <div>
                <div className={styles.pairName}>
                  {selectedCoin.name}{" "}
                  <span className={styles.pairSlash}>/</span> USD
                </div>
                <div className={styles.pairSymbol}>
                  {selectedCoin.symbol}USDT · Spot
                </div>
              </div>
            </div>
            <div className={styles.pairStats}>
              <div
                className={styles.pairPrice}
                style={{ color: positive ? "#22c55e" : "#ef4444" }}
              >
                $
                {selectedCoin.price.toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                })}
              </div>
              <div
                className={`${styles.pairChange} ${positive ? styles.pos : styles.neg}`}
              >
                {positive ? "▲" : "▼"}{" "}
                {Math.abs(selectedCoin.change).toFixed(2)}%
              </div>
              <div className={styles.pairMeta}>
                <span>
                  24h Vol <strong>{selectedCoin.volume}</strong>
                </span>
                <span>
                  H <strong>{selectedCoin.high}</strong>
                </span>
                <span>
                  L <strong>{selectedCoin.low}</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Chart intervals */}
          <div className={styles.intervalRow}>
            {["1m", "5m", "15m", "1H", "4H", "1D", "1W"].map((iv) => (
              <button
                key={iv}
                className={`${styles.intervalBtn} ${chartInterval === iv ? styles.intervalActive : ""}`}
                onClick={() => setChartInterval(iv)}
              >
                {iv}
              </button>
            ))}
            <span className={styles.chartTypeBadge}>Candlestick</span>
          </div>

          {/* Candlestick chart */}
          <div className={styles.chartWrap}>
            <div className={styles.chartPriceLabels}>
              <span>${(selectedCoin.price * 1.015).toFixed(0)}</span>
              <span>${(selectedCoin.price * 1.005).toFixed(0)}</span>
              <span>${selectedCoin.price.toFixed(0)}</span>
              <span>${(selectedCoin.price * 0.99).toFixed(0)}</span>
            </div>
            <div className={styles.chartCanvas}>
              <CandleChart />
            </div>
          </div>

          {/* Volume */}
          <div className={styles.volumeWrap}>
            <span className={styles.volumeLabel}>VOL</span>
            <div className={styles.volumeCanvas}>
              <VolumeChart />
            </div>
          </div>

          {/* Open Orders table */}
          <div className={styles.ordersCard}>
            <div className={styles.ordersTabRow}>
              <button
                className={`${styles.ordersTab} ${ordersTab === "open" ? styles.ordersTabActive : ""}`}
                onClick={() => setOrdersTab("open")}
              >
                Open Orders{" "}
                <span className={styles.badge}>
                  {OPEN_ORDERS.filter((o) => o.status === "Open").length}
                </span>
              </button>
              <button
                className={`${styles.ordersTab} ${ordersTab === "history" ? styles.ordersTabActive : ""}`}
                onClick={() => setOrdersTab("history")}
              >
                Order History
              </button>
            </div>
            <div className={styles.ordersTable}>
              <div className={styles.ordersHead}>
                <span>Date</span>
                <span>Pair</span>
                <span>Type</span>
                <span>Side</span>
                <span>Price</span>
                <span>Amount</span>
                <span>Filled</span>
                <span>Status</span>
              </div>
              {OPEN_ORDERS.filter((o) =>
                ordersTab === "open"
                  ? o.status === "Open" || o.status === "Partial"
                  : o.status === "Filled",
              ).map((o, i) => (
                <div key={i} className={styles.ordersRow}>
                  <span>{o.date}</span>
                  <span className={styles.pairTag}>{o.pair}</span>
                  <span>{o.type}</span>
                  <span
                    className={
                      o.side === "Buy" ? styles.buyText : styles.sellText
                    }
                  >
                    {o.side}
                  </span>
                  <span>{o.price}</span>
                  <span>{o.amount}</span>
                  <span>{o.filled}</span>
                  <span
                    className={
                      o.status === "Open"
                        ? styles.statusOpen
                        : o.status === "Filled"
                          ? styles.statusFilled
                          : styles.statusPartial
                    }
                  >
                    {o.status}
                  </span>
                </div>
              ))}
              {ordersTab === "open" &&
                OPEN_ORDERS.filter(
                  (o) => o.status === "Open" || o.status === "Partial",
                ).length === 0 && (
                  <div className={styles.emptyOrders}>No open orders</div>
                )}
            </div>
          </div>
        </div>

        {/* ── MIDDLE: Order book / trades ── */}
        <div className={styles.bookCol}>
          <div className={styles.bookCard}>
            <div className={styles.bookTabRow}>
              <button
                className={`${styles.bookTab} ${activeTab === "orderbook" ? styles.bookTabActive : ""}`}
                onClick={() => setActiveTab("orderbook")}
              >
                Order Book
              </button>
              <button
                className={`${styles.bookTab} ${activeTab === "trades" ? styles.bookTabActive : ""}`}
                onClick={() => setActiveTab("trades")}
              >
                Trades
              </button>
            </div>

            {activeTab === "orderbook" ? (
              <div className={styles.orderBook}>
                <div className={styles.obHeader}>
                  <span>Price (USD)</span>
                  <span>Amount ({selectedCoin.symbol})</span>
                  <span>Total</span>
                </div>
                {/* Asks */}
                <div className={styles.asks}>
                  {[...ORDER_BOOK_ASKS].reverse().map((a, i) => (
                    <div key={i} className={styles.obRow}>
                      <div
                        className={styles.obDepth}
                        style={{
                          width: `${(a.total / 120000) * 100}%`,
                          background: "rgba(239,68,68,0.08)",
                        }}
                      />
                      <span className={styles.askPrice}>
                        ${a.price.toLocaleString()}
                      </span>
                      <span className={styles.obAmount}>
                        {a.amount.toFixed(4)}
                      </span>
                      <span className={styles.obTotal}>
                        ${a.total.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
                {/* Spread */}
                <div className={styles.spread}>
                  <span
                    style={{
                      color: positive ? "#22c55e" : "#ef4444",
                      fontWeight: 700,
                      fontSize: "15px",
                    }}
                  >
                    $
                    {selectedCoin.price.toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                    })}
                  </span>
                  <span className={styles.spreadLabel}>Spread: $77.50</span>
                </div>
                {/* Bids */}
                <div className={styles.bids}>
                  {ORDER_BOOK_BIDS.map((b, i) => (
                    <div key={i} className={styles.obRow}>
                      <div
                        className={styles.obDepth}
                        style={{
                          width: `${(b.total / 120000) * 100}%`,
                          background: "rgba(34,197,94,0.08)",
                        }}
                      />
                      <span className={styles.bidPrice}>
                        ${b.price.toLocaleString()}
                      </span>
                      <span className={styles.obAmount}>
                        {b.amount.toFixed(4)}
                      </span>
                      <span className={styles.obTotal}>
                        ${b.total.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className={styles.tradesList}>
                <div className={styles.obHeader}>
                  <span>Time</span>
                  <span>Price</span>
                  <span>Amount</span>
                </div>
                {RECENT_TRADES.map((t, i) => (
                  <div key={i} className={styles.tradeRow}>
                    <span className={styles.tradeTime}>{t.time}</span>
                    <span
                      className={
                        t.side === "buy" ? styles.bidPrice : styles.askPrice
                      }
                    >
                      $
                      {t.price.toLocaleString("en-US", {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                    <span className={styles.obAmount}>
                      {t.amount.toFixed(4)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── RIGHT: Order form ── */}
        <div className={styles.formCol}>
          <div className={styles.formCard}>
            {/* Balance pill */}
            <div className={styles.balancePill}>
              <span className={styles.balancePillLabel}>Available Balance</span>
              <span className={styles.balancePillValue}>
                {formatUSD(balance)}
              </span>
            </div>

            {/* Buy / Sell toggle */}
            <div className={styles.sideToggle}>
              <button
                className={`${styles.sideBtn} ${orderSide === "buy" ? styles.sideBtnBuy : ""}`}
                onClick={() => setOrderSide("buy")}
              >
                Buy
              </button>
              <button
                className={`${styles.sideBtn} ${orderSide === "sell" ? styles.sideBtnSell : ""}`}
                onClick={() => setOrderSide("sell")}
              >
                Sell
              </button>
            </div>

            {/* Order type */}
            <div className={styles.typeRow}>
              {(["market", "limit", "stop"] as const).map((t) => (
                <button
                  key={t}
                  className={`${styles.typeBtn} ${orderType === t ? styles.typeBtnActive : ""}`}
                  onClick={() => setOrderType(t)}
                >
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>

            {/* Price input (hidden for market) */}
            {orderType !== "market" && (
              <div className={styles.inputGroup}>
                <label className={styles.inputLabel}>
                  {orderType === "limit" ? "Limit Price" : "Stop Price"} (USD)
                </label>
                <div className={styles.inputWrap}>
                  <span className={styles.inputPrefix}>$</span>
                  <input
                    className={styles.input}
                    type="number"
                    placeholder={selectedCoin.price.toFixed(2)}
                    value={limitPrice}
                    onChange={(e) => setLimitPrice(e.target.value)}
                  />
                </div>
              </div>
            )}

            {orderType === "market" && (
              <div className={styles.marketPriceRow}>
                <span className={styles.inputLabel}>Market Price</span>
                <span
                  className={styles.marketPriceVal}
                  style={{ color: positive ? "#22c55e" : "#ef4444" }}
                >
                  $
                  {selectedCoin.price.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                  })}
                </span>
              </div>
            )}

            {/* Amount */}
            <div className={styles.inputGroup}>
              <label className={styles.inputLabel}>
                Amount ({selectedCoin.symbol})
              </label>
              <div className={styles.inputWrap}>
                <input
                  className={styles.input}
                  type="number"
                  placeholder="0.00000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <span className={styles.inputSuffix}>
                  {selectedCoin.symbol}
                </span>
              </div>
            </div>

            {/* Percentage buttons */}
            <div className={styles.pctRow}>
              {[25, 50, 75, 100].map((p) => (
                <button
                  key={p}
                  className={styles.pctBtn}
                  onClick={() => handlePercentage(p)}
                >
                  {p}%
                </button>
              ))}
            </div>

            {/* Total */}
            <div className={styles.totalRow}>
              <span className={styles.totalLabel}>Estimated Total</span>
              <span className={styles.totalVal}>
                $
                {parseFloat(estTotal).toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                })}
              </span>
            </div>

            {/* Fee estimate */}
            <div className={styles.feeRow}>
              <span className={styles.feeLabel}>Trading Fee (0.1%)</span>
              <span className={styles.feeVal}>
                ${(parseFloat(estTotal) * 0.001).toFixed(2)}
              </span>
            </div>

            {/* Submit */}
            <button
              className={`${styles.submitBtn} ${orderSide === "buy" ? styles.submitBuy : styles.submitSell}`}
            >
              {orderSide === "buy" ? "▲" : "▼"}&nbsp;
              {orderType === "market"
                ? `Market ${orderSide === "buy" ? "Buy" : "Sell"}`
                : `Place ${orderType.charAt(0).toUpperCase() + orderType.slice(1)} Order`}
              &nbsp;{selectedCoin.symbol}
            </button>

            <p className={styles.disclaimer}>
              Demo mode — no real funds are executed. Connect your account to
              trade live.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
