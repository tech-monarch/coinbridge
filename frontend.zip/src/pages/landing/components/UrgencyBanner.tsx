import { Link } from 'react-router-dom';
import styles from './UrgencyBanner.module.css';

export default function UrgencyBanner() {
  return (
    <section className={styles.section}>
      <div className={styles.container}>
        <div className={styles.rocket} data-aos="fade-right">
          <div className={styles.rocketPlaceholder}>
            <img src="/vite.svg" alt="rocket" className={styles.rocketImg}/>
          </div>
        </div>
        <div className={styles.content} data-aos="fade-up" data-aos-delay="100">
          <h2 className={styles.heading}>
            The Future of Money is Digital — Don't Get Left Behind
          </h2>
          <p className={styles.sub}>
            More people are joining the crypto revolution every day.<br />
            Start today and take control of your financial future.
          </p>
        </div>
        <Link to="/register" className={styles.btn} data-aos="fade-left" data-aos-delay="150">
          Create Free Account &nbsp;→
        </Link>
      </div>
    </section>
  );
}
