export { default } from "./InvestPage";
