export { default } from './AcademyPage';
